# UAP Analysis System v3.0

Sistema híbrido de análisis de fenómenos UAP con 3 capas de validación:
- OpenCV (análisis técnico)
- Training Dataset (clasificación supervisada)
- Llama Vision (IA de última generación)

## Demo en vivo
https://uap-analysis.netlify.app

## Proyecto Open Source
Desarrollado por UFO Teoría
